using System;

namespace M9_Ficha06_Sal�rios
{
    public class Salario
    {
        public double salarioBruto;
        public double descontoSegSocial;
        public double descontoIRS;
        public double salarioLiquido;

        // Construtor
        public Salario()
        {
            salarioBruto = 0.0;
            descontoSegSocial = 0.0;
            descontoIRS = 0.0;
            salarioLiquido = 0.0;
        }

        // Destrutor (finalizador)
        ~Salario()
        {
            // Aqu� poderia ser usado para liberar recursos n�o gerenciados, se existissem.
        }

        // M�todo que realiza os c�lculos dos descontos e do sal�rio l�quido
        public void Calcular()
        {
            // Seguran�a Social = 20% do sal�rio bruto
            descontoSegSocial = salarioBruto * 0.20;

            // IRS conforme tabela
            if (salarioBruto < 500.0)
            {
                descontoIRS = 0.0;
            }
            else if (salarioBruto >= 500.0 && salarioBruto < 1500.0)
            {
                descontoIRS = salarioBruto * 0.12;
            }
            else // superior a 1500�
            {
                descontoIRS = salarioBruto * 0.18;
            }

            salarioLiquido = salarioBruto - descontoSegSocial - descontoIRS;
        }
    }
}